package com.capgemini.salesmanagement.exception;

public class ProductException extends Exception {
	
	public ProductException(String exp)
	{
		System.out.println(exp);
	}
	
	

}
