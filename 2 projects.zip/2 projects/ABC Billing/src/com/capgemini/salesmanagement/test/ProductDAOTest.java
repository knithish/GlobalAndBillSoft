package com.capgemini.salesmanagement.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProductDAOTest {

	@Test
	public void testGetProductDetails() {
		
	}

	@Test
	public void testInsertSalesDetails() {
		
	}

}
