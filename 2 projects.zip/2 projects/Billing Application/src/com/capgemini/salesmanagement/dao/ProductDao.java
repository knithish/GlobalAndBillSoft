package com.capgemini.salesmanagement.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.exception.ProductException;
import com.capgemini.salesmanagement.util.DBConnection;

public class ProductDao implements IPoductDao {

	

	@Override
	public ProductBean getProductDetails(int productCode) throws ProductException, SQLException, IOException {
		
		Connection connection=DBConnection.getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		ProductBean productBean=null;
		
		try
		{
			//System.out.println("dao1");
			preparedStatement=connection.prepareStatement(Query.VIEW_PRODUCT_DETAILS_QUERY);
			preparedStatement.setInt(1,productCode);
			resultset=preparedStatement.executeQuery();
			
			while(resultset.next())
			{
				productBean = new ProductBean();
				productBean.setProductName(resultset.getString(1));;
				productBean.setProductCatagory(resultset.getString(2));
				productBean.setProductDescription(resultset.getString(3));
				productBean.setProductPrice(resultset.getInt(4));
				
			}
			
			if( productBean != null)
			{
				//logger.info("Record Found Successfully");
				return productBean;
			}
			else
			{
				//logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//logger.error(e.getMessage());
			throw new ProductException(e.getMessage());
		}
		finally
		{
			try 
			{
				//resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				//logger.error(e.getMessage());
				throw new ProductException("Error in closing db connection");

			}
		}
		
	}

	@Override
	public boolean insertSalesDetails(ProductBean productBean) throws ProductException, IOException {
Connection connection=DBConnection.getConnection();
		//System.out.println("in DAO");
		try
		{
			int quantity=productBean.getQuantity();
			//System.out.println(productBean.getQuantity());
			//System.out.println(productBean.getProductPrice());
			double price=productBean.getProductPrice();
			double total=price*quantity;
			//System.out.println(total);
			productBean.setTotalLine(total);
			PreparedStatement prepareStatement=connection.prepareStatement(Query.INSERT_SALE);
			prepareStatement.setInt(1,productBean.getProductCode());
			prepareStatement.setInt(2, quantity);
			prepareStatement.setDouble(3,total);
			prepareStatement.executeUpdate();	
		}catch(Exception e)
		{
			e.printStackTrace();
		}
				
	return true;
	}
	
}
