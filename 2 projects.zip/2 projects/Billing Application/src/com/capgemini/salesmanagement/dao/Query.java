package com.capgemini.salesmanagement.dao;

public interface Query {

	String VIEW_PRODUCT_DETAILS_QUERY = "SELECT Product_Name,Product_Category,Product_Description,Product_Price FROM product WHERE  Product_Code=?";
	String INSERT_SALE="insert into sales values(salesid_seq.nextval,?,?,sysdate,?)";

}
