package com.capgemini.salesmanagement.ui;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.exception.ProductException;
import com.capgemini.salesmanagement.service.IProductService;
import com.capgemini.salesmanagement.service.ProductService;
public class Client {
	static IProductService service=null;
	static Scanner scanner=new Scanner(System.in);
	static ProductService service1=null;
	public static void main(String[] args) throws SQLException, IOException, ProductException {
		ProductBean productBean=new ProductBean();
		while(true)
		{
			System.out.println("Billing Software Application");
			System.out.println("_____________________________\n");
			System.out.println("1.Generate Bill");
			System.out.println("2.Exit");
			System.out.println("Enter your choice:");
			try
			{
				int choice=scanner.nextInt();
				switch(choice)
				{
				case 1:
					service1=new ProductService();
					System.out.println("Enter the product code:");
					int productCode=scanner.nextInt();
					if(!service1.validateProductCode(productCode))
					{
						System.err.println("Invalid product code!!\n");
						System.out.println("Enter correct product code:");
						productCode=scanner.nextInt();
						service1.validateProductCode(productCode);
					}
					
					System.out.println("Enter the quantity:");
					int quantity=scanner.nextInt();
					
					if(!service1.validateQuantity(quantity))
					{
						System.err.println("Invalid quantity!!");
						System.out.println("Enter correct quantity:");
						quantity=scanner.nextInt();
						
						service1.validateQuantity(quantity);
					}		
					try {
						productBean=getProductDetails(productCode);
						if(productBean!=null)
						{
							
							System.out.println("___________________________________________________\n");
							System.out.println("Product Name:"+productBean.getProductName());
							System.out.println("Product Catagory: "+productBean.getProductCatagory());
							System.out.println("Product Description: "+productBean.getProductDescription());
							System.out.println("Product Price: "+productBean.getProductPrice());
							System.out.println("Quantity: "+quantity);
							System.out.println("Line Total: "+(quantity*productBean.getProductPrice()));
							System.out.println("___________________________________________________\n");
							productBean.setProductCode(productCode);
							productBean.setQuantity(quantity);
							service=new ProductService();
							service.insertSalesDetails(productBean);
						}
						if(productBean==null)
						{
							System.out.println("___________________________________________________\n");
							System.out.println("Product code is invalid!!");
							System.out.println("___________________________________________________\n");
							System.exit(0);
						}
					} catch (ProductException e) {
						
						System.err.println("ERROR: "+e.getMessage());
					}
				
					
					break;
				case 2:
					System.exit(0);
					break;
					default:
						System.out.println("You have entered invalid choice!!");
						System.exit(0);
						break;
				}
			}catch(InputMismatchException e)
			{
				e.printStackTrace();
				System.err.println("Enter a valid choice!! Try Again!!");
				System.exit(0);
			}
		}
	}
	private static ProductBean getProductDetails(int productCode)throws ProductException, SQLException, IOException {
		ProductBean productBean=null;
		service1=new ProductService();
		productBean=service1.getProductDetails(productCode);
		
		return productBean;
	}
	
}
