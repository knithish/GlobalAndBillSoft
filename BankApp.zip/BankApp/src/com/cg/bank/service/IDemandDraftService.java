package com.cg.bank.service;
import java.io.IOException;


import com.cg.bank.bean.DemandDraft;
import com.cg.bank.exception.BankException;

public interface IDemandDraftService {
	int addDemandDraftDetails (DemandDraft demandDraft) throws  IOException, BankException;
	DemandDraft getDemandDraftDetails (int transactionId);
}
