package com.cg.bank.exception;

public class BankException extends Exception{

	public BankException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankException(String string) {
		// TODO Auto-generated constructor stub
	}


}
