package com.cg.bank.dao;

import java.io.IOException;


import com.cg.bank.bean.DemandDraft;
import com.cg.bank.exception.BankException;

public interface IDemandDraftDAO {
	int addDemandDraftDetails (DemandDraft demandDraft) throws  IOException, BankException;
	DemandDraft getDemandDraftDetails (int transactionId);
}
